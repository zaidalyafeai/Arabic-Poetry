import os
import numpy as np
import glob
import random 

files = glob.glob("poems/**.txt")
class_labels = []
all_baits = []

for class_index, file in enumerate(files):
    with open(file, 'r') as f:
        lines = f.readlines()

    i = 0
    class_labels.append(file[6:-4])

    while i < len(lines) -1 :
        all_baits.append(str(class_index)+' '+lines[i].strip() + ' # ' + lines[i+1].strip())
        i += 2

print('The number of baits ', len(all_baits))

random.seed(4)
random.shuffle(all_baits)
split_index = int(0.85 * len(all_baits))

train_baits = all_baits[:split_index]
test_baits  = all_baits[split_index:]

with open('train.txt', 'w') as f:
    f.write('\n'.join(train_baits))

with open('test.txt', 'w') as f:
    f.write('\n'.join(test_baits))

with open('labels.txt', 'w') as f:
    f.write('\n'.join(class_labels))
